from lista4.Questão1.Controll import ClienteController

controle = ClienteController()

controle.inicia()